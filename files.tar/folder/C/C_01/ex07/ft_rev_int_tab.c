/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/29 17:39:02 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/31 18:20:21 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;
	int	j;
	int	temp;

	i = 0;
	j = size - 1;
	while (i <= size / 2)
	{
		temp = tab[i];
		tab[i] = tab [j - i];
		tab[j - i] = temp;
		i++;
	}
}

/*
#include <stdio.h>

int main(void)
{
	int ta[] = {-1, -2, 3, 4, -5, 6, 7};
	//int ta[] = {-1, -2, 3, 4, -5, 6};
	int	i;

	i = 0;
	ft_rev_int_tab(ta, 7); //6
	while (i < 7) //6
	{
		printf("%d", ta[i]);
		i++;
	}
	return(0);
}
//*/