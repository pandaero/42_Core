/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/29 20:06:04 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/30 17:18:29 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* Quick sort algorithm implementation 
Steps
1 - Compare first number to last number, place lower first, higher last, designate partition
2 - Run sorting before the partition and after the partition, separately
3 -

*/
#include <unistd.h>
#include <stdio.h>

void	swap(int *a, int *b)
{
	int t = *a;

	t = *a;
	*a = *b;
	*b = t;
}

void	quicksort(int *tab, int size)
{
	int	i;
	int	j;
	int	pivot;

	pivot = size/2;
	i = 0;
	j = size;
	while (i < j)
	{
		while (tab[i] <= tab[pivot] && i < size)
			i++;
		while (tab[j])
			j--;
		if (i < j)
		{
			swap(arr[i], arr[j]);
		}
	}
	swap(arr[i], arr[j]);
	quicksort(arr, first, j-1);
	quicksort(arr, j+1, last);
}

/* Takes the last element as pivot and sorts smaller than pivot and larger than pivot */
int	partition(int *arr[], int low, int high)
{
	int	pivot;
	int	i;
	int	j;

	pivot = *arr[high];
	i = low - 1;
	j = low;
	while (j <= high - 1)
	{
		if (*arr[j] < pivot)
		{
			swap(arr[i], arr[j]);
			i++;
		}
		j++;
	}
	swap(arr[i + 1], arr[high]);
	return (i + 1);
}

/* This function sorts within a smaller array */
void	minisort(int *arr[], int low, int high)
{
	int part;

	if (low < high)
	{
		part = partition(arr, low, high);
		minisort(arr, low, part - 1);
		minisort(arr, part + 1, high);
	}
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	low;
	int	high;
	int part;

	high = size;
	low = 0;
	if (low < high)
	{
		part = partition(&tab, low, high);
		minisort(&tab, low, part - 1);
		minisort(&tab, part + 1, high);
	}
}

int	main(void)
{
	int	arr[] = {10, 80, 30, 90, 40, 50, 70};
	int size;
	int	i;

	i = 0;
	size = sizeof(arr);
	ft_sort_int_tab(arr, size);
	while (i < size)
	{
		printf("(%d)\n", arr[i]);
		i++;
	}
	return (0);
}
