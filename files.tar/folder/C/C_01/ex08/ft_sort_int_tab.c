/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/30 17:20:22 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/31 18:20:24 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	swap(int *a, int *b)
{
	int	t;

	t = *a;
	*a = *b;
	*b = t;
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < size - 1)
	{
		while (j < size - i - 1)
		{
			if (tab[j] > tab[j + 1])
				swap(&tab[j], &tab[j + 1]);
		j++;
		}
	i++;
	}
}

/*
#include <stdio.h>

int main()
{
	int ta[] = {1,-2,3,9,3,5};
	int	i;

	i = 0;
	ft_sort_int_tab(ta, 6);
	while (i < 6)
	{
		printf("%d", ta[i]);
		i++;
	}
	ft_sort_int_tab(ta, 6);
	return(0);
}
//*/