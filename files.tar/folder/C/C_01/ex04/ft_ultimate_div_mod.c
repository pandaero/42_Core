/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/28 23:01:33 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/28 23:18:34 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	quowho;
	int	quorem;

	quowho = *a / *b;
	quorem = *a % *b;
	*a = quowho;
	*b = quorem;
}
