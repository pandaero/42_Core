/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/28 22:55:46 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/28 23:18:29 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	int	quowho;
	int	quorem;

	quowho = a / b;
	quorem = a % b;
	*div = quowho;
	*mod = quorem;
}
