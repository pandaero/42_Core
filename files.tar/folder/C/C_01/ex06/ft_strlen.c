/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/29 16:23:32 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/29 23:25:13 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int		i;
	int		chars;

	i = 0;
	while (str[i] != '\0')
		i++;
	chars = i;
	return (chars);
}

/* don't forget to #include <unistd.h>
int main(void)
{
	char	*what;
	char	ch_number;
	int		i_number;

	what = "hello";
	i_number = ft_strlen(what);
	ch_number = i_number + '0';
	write(1, &ch_number, 1);
	return 0;
}
*/