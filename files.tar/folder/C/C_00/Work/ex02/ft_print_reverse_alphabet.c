/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/25 09:07:07 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/25 09:13:17 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	ft_print_reverse_alphabet(void)
{
	int		i;
	char	letter;

	i = 25;
	letter = 'z';
	while (i > -1)
	{
		write(1, &letter, 1);
		letter --;
		i --;
	}
}
