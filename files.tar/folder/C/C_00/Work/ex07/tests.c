#include<unistd.h>

int main()
{
	int 	i;
	char	digit;
	char	newline;


	i = 4 % 10;
	newline = '\n';
	digit = '0' + i;
	write(1, &digit, 1);
	write(1, &newline, 1);
	return(0);
}
