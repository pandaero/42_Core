/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/25 08:58:44 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/25 09:03:16 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	ft_print_alphabet(void)
{
	int		i;
	char	letter;

	i = 0;
	letter = 'a';
	while (i < 26)
	{
		write(1, &letter, 1);
		letter ++;
		i++;
	}
}
