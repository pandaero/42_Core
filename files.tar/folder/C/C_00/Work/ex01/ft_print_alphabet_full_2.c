/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet_full_2.c                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/25 07:53:33 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/25 08:58:22 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	ft_print_alphabet(void)
{
	int		i;
	char	letter;

	i = 0;
	letter = 'a';
	while (i < 26)
	{
		write(1, &letter, 1);
		letter ++;
		i ++;
	}
}

int	main(void)
{
	ft_print_alphabet();
	return (0);
}
