/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/25 11:03:59 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/27 11:56:43 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

void	spacing(void)
{
	char	comma;
	char	space;

	comma = ',';
	space = ' ';
	write(1, &comma, 1);
	write(1, &space, 1);
}

void	makepair(int fpa, int spa)
{
	char	print;

	print = '0' + (fpa / 10);
	write(1, &print, 1);
	print = '0' + (fpa % 10);
	write(1, &print, 1);
	write(1, " ", 1);
	print = '0' + (spa / 10);
	write(1, &print, 1);
	print = '0' + (spa % 10);
	write(1, &print, 1);
}

void	ft_print_comb2(void)
{
	int		fpair;
	int		spair;

	fpair = 00;
	spair = 01;
	while (fpair <= 98)
	{
		spair = fpair + 1;
		while (spair <= 99)
		{
			makepair(fpair, spair);
			if (spair != 99 || fpair != 98)
				spacing();
			spair ++;
		}
		fpair ++;
	}
}

/*
int	main(void)
{
	ft_print_comb2();
}
*/