#!/bin/sh
find -type f -name "*.sh" | tr -d ".sh"