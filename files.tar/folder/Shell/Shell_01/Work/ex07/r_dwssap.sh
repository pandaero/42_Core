#!/bin/sh
#FT_LINE1=3
#FT_LINE2=16
cat /etc/passwd | awk "NR % 2 == 0" | cut -d : -f 1 | rev | sort -r | sed -n "$FT_LINE1,$FT_LINE2 p" | tr "\n" "," | sed 's/\(.*\),/\1./' | sed 's/\(,\)/, /g'
