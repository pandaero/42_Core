#!/bin/sh
#FT_NBR1=\\\'?\"\\\"\'\\
#FT_NBR2=rcrdmddd
#FT_NBR1=\\\"\\\"!\\\"\\\"!\\\"\\\"!\\\"\\\"!\\\"\\\"!\\\"\\\"
#FT_NBR2=dcrcmcmooododmrrrmorcmcrmomo
BASE_NBR1=5
BASE_NBR2=5
BASE_RESULT=13
echo "obase=$BASE_RESULT;ibase=$BASE_NBR1;" $FT_NBR1 + $FT_NBR2 | tr "\'" '0' | tr '\\\"\?\!mrdoc' "123401234" | sed 's/3/o/' | bc | tr '0123456789ABC' 'gtaio\ luSnemf'
