#!/bin/sh
#FT_USER=pulse
id -Gn $FT_USER | tr " " "," | tr -d "\n"
