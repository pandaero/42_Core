#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int main (void)
{
	int		fd;
	int		rd;
	int		new;
	char	bf[1];

	fd = open("file", O_RDONLY);
	if (fd == -1)
		printf("Open Error\n");
	while ((rd = read(fd, bf, 1) != 0))
	{
		if (bf[rd] == '\n')
			new++;
	}
	printf("New lines: %d\n", new);
	return (0);
}