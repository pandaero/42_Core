/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   showmaperror.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/06 13:29:30 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/06 14:07:41 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Function to show error message
*/

#include <unistd.h>

void	showmaperror(void)
{
	write(1, "map error\n", 11);
}

/* Test
//gcc -Wall -Werror -Wextra showmaperror.c && ./a.out | cat -e

int	main(void)
{
	showmaperror();
	return (0);
}
//*/