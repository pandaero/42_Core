/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mapsize.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/06 14:08:14 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/06 21:47:53 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Function reads a map file and returns dimensions. x in 0 index, y in 0 index
*/

#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

void	showmemerror(void);

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= ' ' && str[i] <= '~'))
			return (0);
		i++;
	}
	return (1);
}

int	*mapsize(char *filename)
{
	int		fd;
	int		rd;
	int		*size;
	char	bf[1];

	size = malloc(8);
	size[0] = 0;
	size[1] = 0;
	fd = open(filename, O_RDONLY);
	while ((rd = read(fd, bf, 1)) != 0)
	{
		if (bf[0] == '\n')
			size[1]++;
		if (size[1] == 1 && ft_str_is_printable(bf) == 1)
			size[0]++;
	}
	free(size);
	size[1] -= 1;
	return (size);
}

/* Test
#include <stdio.h>

int	main(void)
{
	int *siz;
	char file[] = "map1";

	siz = mapsize(file);
	printf("Size\nx: %d, y: %d\n", siz[0],siz[1]);
	return (0);
}
//*/