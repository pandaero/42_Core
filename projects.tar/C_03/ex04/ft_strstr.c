/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/31 23:44:16 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/31 23:44:16 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Function looks for string to_find in str and returns pointer to the first
character appearing in str when the complete term is found.
Otherwise null pointer
-------------------------
Outline
----- while search moves along str
---------- while checking for exact match
--------------- if exact match, return location pointer
----- else return null pointer
*/
unsigned int	ft_strlen(char *str)
{
	int	i;
	int	chars;

	i = 0;
	while (str[i] != '\0')
		i++;
	chars = i;
	return (chars);
}

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	unsigned int	chars;

	i = 0;
	chars = ft_strlen(s1);
	while (s1[i] != '\0' && i <= n)
	{
		if (s1[i] != s2[i] || chars < n)
			return (0);
		i++;
	}
	return (1);
}

char	*ft_strstr(char *str, char *to_find)
{
	char			*ptr;
	char			comp[256];
	unsigned int	length;
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	ptr = 0;
	length = ft_strlen(to_find);
	while (str[j + length] != '\0')
	{
		i = 0;
		while (i <= j + length)
		{
			comp[i] = str[j];
			i++;
		}
		if (ft_strncmp(comp, to_find, length) == 1)
		{
			ptr = &str[j];
			return (ptr);
		}
	j++;
	}
	return (ptr);
}

//*
#include <stdio.h>
//#include <string.h>

int	main(void)
{
	char			s1[100] = "Hello world!";
	char			s2[] = "worldse";
	char			*ret;

	ret = ft_strstr(s1, s2);
	printf("\nString: %s\nSearch: %s\n%x\n", s1, s2, *ret);
	return (0);
}
//*/