/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/31 21:53:32 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/31 21:53:32 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Function returns 1 if s1 and s2 UP TO n (of s1) are the same. Returns 0 otherwise.
Check character for character UP TO n, as soon as they aren't, return 0.
Check length because if s1 is shorter than s2 and n is larger than s1 can be,
they can't be the same.
*/
unsigned int	ft_strlen(char *str)
{
	int	i;
	int	chars;

	i = 0;
	while (str[i] != '\0')
		i++;
	chars = i;
	return (chars);
}

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	unsigned int	chars;

	i = 0;
	chars = ft_strlen(s1);
	while (s1[i] != '\0' && i <= n)
	{
		if (s1[i] != s2[i] || chars < n)
			return (0);
		i++;
	}
	return (1);
}

/*
#include <stdio.h>
#include <string.h>
int	main(void)
{
	char	*s1;
	char	*s2;
	char	*out;
	int		ret;
	int		t1;
	int		t2;

	s1 = "hello world";
	s2 = "hello marvin";
	out = "Up to ";
	t1 = 5;
	t2 = 9;
	ret = ft_strncmp(s1, s2, t1);
	printf("\n%s\n%s\n%s%d\n%d\n", s1, s2, out, t1, ret);
	ret = ft_strncmp(s1, s2, t2);
	printf("\n%s\n%s\n%s%d\n%d\n", s1, s2, out, t2, ret);
	ret = ft_strlen(s1);
	printf("\n%d\n", ret);
	return (0);
}
//*/