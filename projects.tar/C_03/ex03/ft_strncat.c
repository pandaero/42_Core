/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/31 23:17:42 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/31 23:17:42 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Functions adds string src UP TO nb characters to string dest.
(as long as dest is big enough)
strncat does result in segmentation errors when that is not the case, so it
will not be prevented. Length needs to be checked for index to start on.
Empty character corresponds to \0, so be careful (can have ...\0\0\0)
This exploits the simple strlen behaviour.
*/
unsigned int	ft_strlen(char *str)
{
	int	i;
	int	chars;

	i = 0;
	while (str[i] != '\0')
		i++;
	chars = i;
	return (chars);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	destsz;
	unsigned int	i;
	
	destsz = ft_strlen(dest);
	while (src[i] != '\0' && i < nb)
	{
		dest[destsz + i] = src[i];
		i++;
	}
	return (dest);
}

/*
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char			s1[100] = "Hello ";
	char			s2[20] = "world!";
	char			initial[100];
	char			out[] = "Up to ";
	unsigned int	nbr = 3;

	strcpy(initial, s1);
	printf("\n%s\n%s\n%s%d\n\n%s\n", initial, s2, out, nbr, ft_strncat(s1, s2, nbr));
	return (0);
}
//*/