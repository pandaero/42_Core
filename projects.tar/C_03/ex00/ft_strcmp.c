/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/31 21:37:13 by pandalaf          #+#    #+#             */
/*   Updated: 2022/03/31 21:37:13 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* 
Function returns 1 if the strings are the same, 0 otherwise 
Check character by character if the same, as soon as they aren't, return 0,
if they are, return 1
*/
int ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] != '\0')
	{
		if (s1[i] != s2[i])
			return (0);
		i++;
	}
	return (1);
}

/*
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char	*s1;
	char	*s2;
	char	*s3;
	int		ret;

	s1 = "hello";
	s2 = "hello";
	s3 = "world";
	ret = ft_strcmp(s1, s2);
	printf("\n%s\n%s\n%d\n", s1, s2, ret);
	ret = ft_strcmp(s1, s3);
	printf("\n%s\n%s\n%d\n", s1, s3, ret);
	return (0);
}
//*/