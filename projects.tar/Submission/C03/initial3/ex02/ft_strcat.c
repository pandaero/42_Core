/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/31 22:31:49 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/07 11:36:07 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Function adds string src to string dest. (as long as dest is large enough)
strcat does result in segmentation errors when that is not the case, so it
will not be prevented. Length needs to be checked for index to start on.
Empty character corresponds to \0, so be careful (can have ...\0\0\0)
*/

char	*ft_strcat(char *dest, char *src)
{
	unsigned int	destsz;
	int				i;

	i = 0;
	destsz = 0;
	while (dest[destsz] != '\0')
		destsz++;
	while (src[i] != '\0')
	{
		dest[destsz + i] = src[i];
		i++;
	}
	dest[destsz + i + 1] = '\0';
	return (dest);
}

/* Test
//gcc -Wall -Werror -Wextra ft_strcat.c && ./a.out | cat -e
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char	dest[100] = "Hello dude, welcome to our ";
	char	dest2[100];
	char	initial[100];
	char	initial2[100];
	char	src[50] = "world! It is bright and scorching, but I'm sure...";

	strcpy(initial, dest); //Copy dest to display it later
	strcpy(initial2, initial);
	strcpy(dest2, initial2);
	printf("Mine\n");
	printf("Dest: %s\nSrc: %s\nOut: %s\n", initial, src, ft_strcat(dest, src));
	printf("----|----|----|----|----|----|----\n");
	printf("Library\n");
	printf("Dest: %s\nSrc: %s\nOut: %s\n", initial2, src, strcat(dest2, src));
	return (0);
}
//*/