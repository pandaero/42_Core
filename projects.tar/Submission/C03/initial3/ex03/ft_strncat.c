/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/31 23:17:42 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/07 16:58:42 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Functions adds string src UP TO nb characters to string dest.
(as long as dest is big enough)
strncat does result in segmentation errors when that is not the case, so it
will not be prevented. Length needs to be checked for index to start on.
Empty character corresponds to \0, so be careful (can have ...\0\0\0)
*/

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	destsz;
	unsigned int	i;

	i = 0;
	destsz = 0;
	while (dest[destsz] != '\0')
		destsz++;
	while (src[i] != '\0' && i < nb)
	{
		dest[destsz + i] = src[i];
		i++;
	}
	dest[destsz + i + 1] = '\0';
	return (dest);
}

/* Test
//gcc -Wall -Werror -Wextra ft_strncat.c && ./a.out | cat -e
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char	dest[100] = "Hello dude, welcome to our ";
	char	dest2[100];
	char	initial[100];
	char	initial2[100];
	char	src[50] = "world!";
	unsigned int	nbr;

	nbr = 10;
	strcpy(initial, dest); //Copy dest to display it later
	strcpy(initial2, initial);
	strcpy(dest2, initial2);
	printf("Mine\n");
	printf("Dest: %s\nSrc: %s\nOut: %s\n", initial,
		src, ft_strncat(dest, src, nbr));
	printf("----|----|----|----|----|----|----\n");
	printf("Library\n");
	printf("Dest: %s\nSrc: %s\nOut: %s\n", initial2,
		src, strncat(dest2, src, nbr));
	return (0);
}
//*/