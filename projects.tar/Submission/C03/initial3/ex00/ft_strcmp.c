/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/31 21:37:13 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/06 22:52:09 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* 
Function returns 0 if the strings are the same, or the value difference between
the first/second and first/second character that is different between the strs
Check character by character if the same, as soon as they aren't, check diff,
and print out the int.
*/
int	ft_strcmp(char *s1, char *s2)
{
	int	i;
	int	diff;

	i = 0;
	diff = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		if (s1[i] != s2[i])
		{
			diff = s1[i] - s2[i];
			return (diff);
		}
		else if (s1[i] == s2[i])
			i++;
	}
	return (0);
}

/* Test
//gcc -Wall -Werror -Wextra ft_strcmp.c && ./a.out | cat -e
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char	*s1;
	char	*s2;
	char	*s3;

	s1 = "hf\0md";
	s2 = "\0hemd";
	s3 = "hforldofpain";
	printf("Mine\n");
	printf("S1: %s\nS2: %s\nOut: %d\n", s1, s2, ft_strcmp(s1, s2));
	printf("S1: %s\nS2: %s\nOut: %d\n", s1, s3, ft_strcmp(s1, s3));
	printf("----|----|----|----|----|----|----\n");
	printf("Library\n");
	printf("S1: %s\nS2: %s\nOut: %d\n", s1, s2, strcmp(s1, s2));
	printf("S1: %s\nS2: %s\nOut: %d\n", s1, s3, strcmp(s1, s3));
	return (0);
}
//*/