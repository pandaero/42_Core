/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/31 21:53:32 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/06 23:18:39 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Function returns 0 if s1 and s2 UP TO n (of s1) are same.
Returns ASCII value difference of the first different character otherwise.
*/
int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	int				diff;

	i = 0;
	diff = 0;
	while ((s1[i] != '\0' || s2[i] != '\0') && i < n)
	{
		if (s1[i] != s2[i])
		{
			diff = s1[i] - s2[i];
			return (diff);
		}
		else if (s1[i] == s2[i])
			i++;
	}
	return (0);
}

/* Test
//gcc -Wall -Werror -Wextra ft_strncmp.c && ./a.out | cat -e
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char	*s1;
	char	*s2;
	char	*s3;
	int		t1;

	t1 = 20;
	s1 = "hey world";
	s2 = "hey marvin";
	s3 = "you what?";
	printf("Mine\n");
	printf("S1: %s\nS2: %s\nUp to: %d\nOut: %d\n", s1, s2, t1,
		ft_strncmp(s1, s2, t1));
	printf("S1: %s\nS2: %s\nUp to: %d\nOut: %d\n", s1, s3, t1,
		ft_strncmp(s1, s3, t1));
	printf("----|----|----|----|----|----|----\n");
	printf("Library\n");
	printf("S1: %s\nS2: %s\nUp to: %d\nOut: %d\n", s1, s2, t1,
		strncmp(s1, s2, t1));
	printf("S1: %s\nS2: %s\nUp to: %d\nOut: %d\n", s1, s3, t1,
		strncmp(s1, s3, t1));
	return (0);
}
//*/