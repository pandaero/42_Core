/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/05 09:23:08 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/05 09:59:47 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
			str[i] = str[i] - ' ';
		i++;
	}
	return (str);
}

/* Test
#include <stdio.h>

int	main(void)
{
	char	string[50] = "HELLOOOd  earfriend~503*&(/!_?><";
	char	stringnot[50] = "H0pe There is a lower";
	char	stringety[5] = "\0";

	printf("Test 1: %s\nResult 1: %s\n\n", string, ft_strupcase(string));
	printf("Test 2: %s\nResult 2: %s\n\n", stringnot, ft_strupcase(stringnot));
	printf("Test 3: %s\nResult 3: %s\n\n", stringety, ft_strupcase(stringety));
	return (0);
}
//*/