/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/04 20:48:41 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/04 21:36:51 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= ' ' && str[i] <= '~'))
			return (0);
		i++;
	}
	return (1);
}

/* Test
#include <stdio.h>

int	main(void)
{
	char	string[50] = "HELLOOOd  earfriend~503*&(/!_?><";
	char	stringnot[50] = "H0pe There is a\t tab ";
	char	stringempty[5] = "\0";
	int		test1;
	int		test2;
	int		test3;

	test1 = ft_str_is_printable(string);
	test2 = ft_str_is_printable(stringnot);
	test3 = ft_str_is_printable(stringempty);
	printf("Test 1: %s\nResult 1: %d\n\n", string, test1);
	printf("Test 2: %s\nResult 2: %d\n\n", stringnot, test2);
	printf("Test 3: %s\nResult 3: %d\n\n", stringempty, test3);
	return (0);
}
//*/