/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/05 10:12:48 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/05 10:45:17 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Function returns true - 1 or false - 0 for index in string qualifying
- Is non-printable
- is punctuation
- is first character of string 
*/
int	scanner(char *str, int i)
{
	if ((i < 0) || (str[i] >= '\t' && str[i] <= '\f'))
		return (1);
	else if ((str[i] >= ' ' && str[i] < '0') || (str[i] > '9' && str[i] < 'A'))
		return (1);
	else if ((str[i] > 'Z' && str[i] < 'a') || (str[i] > 'z' && str[i] <= '~'))
		return (1);
	return (0);
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if ((scanner(str, i - 1) == 1) && (str[i] >= 'a' && str[i] <= 'z'))
			str[i] = str[i] - ' ';
		i++;
	}
	return (str);
}

/* Test
#include <stdio.h>

int	main(void)
{
	char	str[50] = "Hd  end~asd5df0s3*sdf&dfc(fd/fb!dg_sf?dfg>sdf<sdf";
	char	strn[50] = "h0pe There is a lower";
	char	stre[5] = "\0";
	char	strc[50] = "Hd  end~asd5df0s3*sdf&dfc(fd/fb!dg_sf?dfg>sdf<sdf";
	char	strnc[50] = "h0pe There is a lower";
	char	strec[5] = "\0";

	printf("Test 1:   %s\nResult 1: %s\n\n", strc, ft_strcapitalize(str));
	printf("Test 2:   %s\nResult 2: %s\n\n", strnc, ft_strcapitalize(strn));
	printf("Test 3:   %s\nResult 3: %s\n\n", strec, ft_strcapitalize(stre));
	return (0);
}
//*/