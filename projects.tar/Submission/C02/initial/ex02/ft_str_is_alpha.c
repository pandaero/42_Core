/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/04 18:44:23 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/04 20:09:35 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!((str[i] > '@' && str[i] < '[') || (str[i] > '`' && str[i] < '{')))
			return (0);
		i++;
	}
	return (1);
}

/* Test
#include <stdio.h>

int	main(void)
{
	char	string[50] = "Hellooooo";
	char	stringnota[50] = "Hell00000";
	char	stringempty[5] = "\0";
	int		test1;
	int		test2;
	int		test3;

	test1 = ft_str_is_alpha(string);
	test2 = ft_str_is_alpha(stringnota);
	test3 = ft_str_is_alpha(stringempty);
	printf("Test 1: %s\nResult 1: %d\n\n", string, test1);
	printf("Test 2: %s\nResult 2: %d\n\n", stringnota, test2);
	printf("Test 3: %s\nResult 3: %d\n\n", stringempty, test3);
	return (0);
}
//*/