/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/04 13:48:41 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/04 19:41:45 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int		i;
	char				src_cp[100];

	i = 0;
	while (i <= n)
	{
		src_cp[i] = '\0';
		i++;
	}
	i = 0;
	while (src[i] != '\0')
	{
		src_cp[i] = src[i];
		i++;
	}
	i = 0;
	while (dest[i] != '\0' && i < n)
	{
		dest[i] = src_cp[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

/* Test
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char	dest[100] = "Hello ";
	char	cpy[100] = "Hello ";
	char	src[6] = "world";
	int		n;

	n = 3;
	printf("dest: %s\nsrc: %s\nResult: %s\n", cpy, src, ft_strncpy(dest, src, n));
}
//*/