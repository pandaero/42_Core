/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/05 10:08:35 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/05 22:31:40 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] = str[i] + ' ';
		i++;
	}
	return (str);
}

/* Test
#include <stdio.h>

int	main(void)
{
	char	string[50] = "HELLOOOd  earfriend~503*&(/!_?><";
	char	stringnot[50] = "H0pe There is a lower";
	char	stringety[5] = "\0";

	printf("Test 1: %s\nResult 1: %s\n\n", string, ft_strlowcase(string));
	printf("Test 2: %s\nResult 2: %s\n\n", stringnot, ft_strlowcase(stringnot));
	printf("Test 3: %s\nResult 3: %s\n\n", stringety, ft_strlowcase(stringety));
	return (0);
}
//*/