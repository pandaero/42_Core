/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/04 13:48:41 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/05 22:23:56 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;
	unsigned int	len;

	i = 0;
	while (src[i] != '\0')
		i++;
	len = i;
	i = 0;
	while (i < n)
	{
		if (i < len)
			dest[i] = src[i];
		else
			dest[i] = '\0';
		i++;
	}
	return (dest);
}

/* Test
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char	dest[100] = "oooooooooooooooo";
	char	cpy[100] = "oooooooooooooooo";
	char	src[6] = "wirld";
	char	destc[100] = "oooooooooooooooo";
	char	cpyc[100] = "oooooooooooooooo";
	char	srcc[6] = "wirld";
	int		n;

	n = 10;
	printf("dest: %s\nsrc: %s\nResult: %s\n", cpy, src, ft_strncpy(dest, src, n));
	printf("dest: %s\nsrc: %s\nResult: %s\n", cpyc, srcc, strncpy(destc, srcc, n));
}
//*/