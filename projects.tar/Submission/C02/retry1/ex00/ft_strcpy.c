/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pandalaf <pandalaf@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/04 13:48:41 by pandalaf          #+#    #+#             */
/*   Updated: 2022/04/05 22:26:09 by pandalaf         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

/* Test
#include <stdio.h>
#include <string.h>

int	main(void)
{
	char dest[100] = "Hello ";
	char cpy[100] = "Hello ";
	char src[6] = "world";
	char destc[100] = "Hello ";
	char cpyc[100] = "Hello ";
	char srcc[6] = "world";

	printf("Mine\ndest: %s\nsrc: %s\nResult: %s\n\n",
		cpy, src, ft_strcpy(dest, src));
	printf("Ideal\ndest: %s\nsrc: %s\nResult: %s\n",
		cpyc, srcc, ft_strcpy(destc, srcc));
}
//*/